# CIVOCI AI Telegram Support Bot

Premium-style starter project for `@CIVOCI_AI_Bot`.

## Features
- `/start` welcome screen with premium emoji menu
- How to Get CIVOCI AI
- How to Deposit
- Verify Your Quotex Account
- Contact Support
- `/help` and `/id`
- Easy-to-edit message text

## Run on a computer or hosting
1. Install Python 3.10 or newer.
2. Extract this ZIP.
3. Rename `.env.example` to `.env`.
4. Paste your Telegram bot token after `BOT_TOKEN=`.
5. Install packages:
   `pip install -r requirements.txt`
6. Start:
   `python bot.py`

## Run on Android (Termux)
1. Install Termux from a trusted source.
2. Run: `pkg update && pkg install python`
3. Enter the extracted project folder.
4. Run: `pip install -r requirements.txt`
5. Copy `.env.example` to `.env` and add your bot token.
6. Run: `python bot.py`

## Important
- Never share your bot token publicly.
- The bot token is intentionally not included in this ZIP.
- Replace the placeholder deposit/verification instructions with your official details.
- Add your verification tutorial URL in `bot.py` when the video is ready.
- Keep the bot running on a hosting service or in an active Termux session.

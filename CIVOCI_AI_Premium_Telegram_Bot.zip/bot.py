import asyncio
import logging
import os
from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command, CommandStart
from aiogram.types import Message, ReplyKeyboardMarkup, KeyboardButton
from dotenv import load_dotenv

load_dotenv()
TOKEN = os.getenv("BOT_TOKEN", "").strip()
ADMIN_ID = int(os.getenv("ADMIN_ID", "0") or 0)

logging.basicConfig(level=logging.INFO)
dp = Dispatcher()

MENU = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="🚀 How to Get CIVOCI AI")],
        [KeyboardButton(text="💳 How to Deposit")],
        [KeyboardButton(text="🎥 Verify Your Quotex Account")],
        [KeyboardButton(text="🆘 Contact Support")],
    ],
    resize_keyboard=True,
    input_field_placeholder="Choose an option…"
)

WELCOME = (
    "✨ <b>WELCOME TO CIVOCI AI SUPPORT</b>\n\n"
    "Your official support assistant.\n"
    "Choose an option below to get started.\n\n"
    "⚡ Fast • Simple • Reliable"
)

@dp.message(CommandStart())
async def start(message: Message):
    await message.answer(WELCOME, reply_markup=MENU, parse_mode="HTML")

@dp.message(Command("help"))
async def help_cmd(message: Message):
    await message.answer("Use the menu buttons below to explore CIVOCI AI support.", reply_markup=MENU)

@dp.message(F.text == "🚀 How to Get CIVOCI AI")
async def get_civoci(message: Message):
    await message.answer(
        "🚀 <b>HOW TO GET CIVOCI AI</b>\n\n"
        "1. Contact our official support.\n"
        "2. Ask for the available plans.\n"
        "3. Complete the activation process.\n"
        "4. Follow the instructions provided by our team.\n\n"
        "📩 Support: @CIVOCI_AI_Bot",
        parse_mode="HTML"
    )

@dp.message(F.text == "💳 How to Deposit")
async def deposit(message: Message):
    await message.answer(
        "💳 <b>DEPOSIT GUIDE</b>\n\n"
        "Please contact support for the current payment method and verified deposit instructions.\n"
        "⚠️ Always confirm payment details with the official support account before sending money.\n\n"
        "📩 Support: @CIVOCI_AI_Bot",
        parse_mode="HTML"
    )

@dp.message(F.text == "🎥 Verify Your Quotex Account")
async def verify(message: Message):
    await message.answer(
        "🎥 <b>QUOTEX ACCOUNT VERIFICATION</b>\n\n"
        "Follow the official verification instructions supplied by support.\n"
        "A tutorial video link can be added here when it is ready.\n\n"
        "📩 Support: @CIVOCI_AI_Bot",
        parse_mode="HTML"
    )

@dp.message(F.text == "🆘 Contact Support")
async def support(message: Message):
    await message.answer(
        "🆘 <b>NEED HELP?</b>\n\n"
        "Send your question to our support team:\n"
        "👉 @CIVOCI_AI_Bot\n\n"
        "Please include a short description of your issue.",
        parse_mode="HTML"
    )

@dp.message(Command("id"))
async def show_id(message: Message):
    await message.answer(f"Your Telegram ID: <code>{message.from_user.id}</code>", parse_mode="HTML")

@dp.message()
async def fallback(message: Message):
    await message.answer(
        "Thanks for your message! Please choose an option from the menu or contact @CIVOCI_AI_Bot.",
        reply_markup=MENU
    )

async def main():
    if not TOKEN:
        raise RuntimeError("BOT_TOKEN is missing. Add your bot token to the .env file.")
    bot = Bot(TOKEN)
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
